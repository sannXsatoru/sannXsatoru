const client = require("../Merpati");

client.on("modalSubmit", async(modal) => {
    
})